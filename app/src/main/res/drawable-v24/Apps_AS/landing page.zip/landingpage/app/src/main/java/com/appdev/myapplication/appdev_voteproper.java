package com.appdev.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;


public class appdev_voteproper extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appdev_voteproper);

        Toolbar tb=(Toolbar)findViewById(R.id.toolbar);
        tb.setTitle("Photo Vote");
        tb.setLogo(R.drawable.ic_camera_24);
        setSupportActionBar(tb);
    }
}