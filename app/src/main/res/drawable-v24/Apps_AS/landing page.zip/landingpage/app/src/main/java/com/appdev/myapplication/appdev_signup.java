package com.appdev.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class appdev_signup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appdev_signup);
    }
}